
n_layer = 12
n_head = 12
n_embd = 768
dropout = 0.0
bias = False
model_name = 'base'
