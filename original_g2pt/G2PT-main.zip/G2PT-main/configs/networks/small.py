
n_layer = 6
n_head = 6
n_embd = 384
dropout = 0.0
bias = False
model_name = 'small'