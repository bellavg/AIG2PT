
n_layer = 24
n_head = 16
n_embd = 1024
dropout = 0.0
bias = False
model_name = 'large'
