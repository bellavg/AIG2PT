
block_size = 85
vocab_size = 30 # more than the one in tokenizer to allow new token introduction.
dataset = 'qm9'