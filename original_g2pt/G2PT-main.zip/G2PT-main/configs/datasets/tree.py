
block_size = 446
vocab_size = 80 # more than the one in tokenizer to allow new token introduction.
dataset = 'tree'