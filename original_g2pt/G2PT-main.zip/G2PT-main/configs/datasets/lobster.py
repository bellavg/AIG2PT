
block_size = 698
vocab_size = 110 # more than the one in tokenizer to allow new token introduction.
dataset = 'lobster'