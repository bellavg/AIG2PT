
block_size = 918
vocab_size = 100 # more than the one in tokenizer to allow new token introduction.
dataset = 'planar'