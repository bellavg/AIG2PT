
block_size = 614
vocab_size = 120 # more than the one in tokenizer to allow new token introduction.
dataset = 'guacamol'