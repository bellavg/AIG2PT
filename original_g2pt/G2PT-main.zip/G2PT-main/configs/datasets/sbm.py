
block_size = 5080
vocab_size = 200 # more than the one in tokenizer to allow new token introduction.
dataset = 'sbm'