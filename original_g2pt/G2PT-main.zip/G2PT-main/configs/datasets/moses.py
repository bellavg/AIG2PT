
block_size = 207
vocab_size = 60 # more than the one in tokenizer to allow new token introduction.
dataset = 'moses'