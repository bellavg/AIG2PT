wandb_log = True
wandb_project = 'g2pt'
batch_size = 60
gradient_accumulation_steps = 8
ordering = 'bfs'
