# TPU Tile

The TpuGraphs dataset is released at https://github.com/google-research-datasets/tpu_graphs/tree/main under the license of Apache-2.0. We adapt the tile collection of the dataset by averaging the normalized runtimes acorss compiler configurations.
